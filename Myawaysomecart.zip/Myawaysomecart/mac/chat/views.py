from django.shortcuts import render,redirect 
from chat.models import Room, Message
from django.http import HttpResponse, JsonResponse

# Create your views here.
def home(request):
    return render(request, 'chat/home.html')

def room(request,room):
    
    username = request.GET.get('username')
    room_details = Room.objects.get(name=room)
    return redirect(request, 'chat/ room.html', {
        'username': username,
        'room': room_details,
        'room_details': room_details
    })

def checkview(request):
    # import pdb; pdb.set_trace();
    room = request.POST['room_name']
    username = request.POST['username']

    if Room.objects.filter(name=room).exists():
        return redirect ('/'+room+'/?username='+username)
        return render(request, 'chat/room.html', {
            'username': username,
            'room': room,
            
        })

        
        
    
    else:
        new_room = Room.objects.create(name=room)
        new_room.save()
        # return redirect('/'+room+'/?username='+username)
        return render(request, 'chat/room.html', {
            'username': username,
            'room': room,
        })
        

def send(request):
    message = request.POST['message']
    username = request.POST['username']
    room_id = request.POST['room_id']

    new_message = Message.objects.create(value=message, user=username, room=room_id)
    new_message.save()
    
    return HttpResponse('Message sent successfully')
    # return render(request, 'chat/room.html')
    # return render(request, 'chat/room.html', {
    #         'username': username,
    #         'room': room,
    #     })

def getMessages(request, room):
    
    
    room_details = Room.objects.get(name=room)

    Room = Message.objects.filter(room=room_details.id)
    # return render(request, 'chat/room.html')
    # return JsonResponse({"messages":list(messages.values())})
    # return render(request, 'chat/room.html', {
    #         'room': room,
    #     })